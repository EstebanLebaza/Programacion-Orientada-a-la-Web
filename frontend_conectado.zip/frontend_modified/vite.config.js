import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': '/src'
    }
  },
  server: {
    proxy: {
      // Redirige /api/* al backend en desarrollo
      '/api': {
        target: 'http://localhost:3000',
        changeOrigin: true
      }
    }
  }
})
