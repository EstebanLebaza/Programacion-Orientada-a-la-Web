import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import HarryView from '../views/HarryView.vue'
import JugadoresView from '../views/JugadoresView.vue'
import PerfilView from '../views/PerfilView.vue'
import UsuariosView from '../views/UsuariosView.vue'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: HomeView
  },
  {
    path: '/harry',
    name: 'Harry',
    component: HarryView
  },
  {
    path: '/jugadores',
    name: 'Jugadores',
    component: JugadoresView
  },
  {
    path: '/perfil',
    name: 'Perfil',
    component: PerfilView
  },
  {
    path: '/usuarios',
    name: 'Usuarios',
    component: UsuariosView
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
