import axios from 'axios'

// En desarrollo, Vite redirige /api → http://localhost:3000/api (ver vite.config.js)
// En producción, cambia BASE_URL a la URL real de tu backend
const BASE_URL = '/api'

const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' }
})

export const userService = {
  getAll: () => api.get('/users'),
  getById: (id) => api.get(`/users/${id}`),
  create: (data) => api.post('/users', data),
  update: (id, data) => api.put(`/users/${id}`, data),
  remove: (id) => api.delete(`/users/${id}`)
}

export default api
