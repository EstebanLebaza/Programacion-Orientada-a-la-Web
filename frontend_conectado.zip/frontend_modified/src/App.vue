<template>
  <div id="app">
    <!-- Navbar directamente en App.vue -->
    <nav class="navbar">
      <div class="nav-container">
        <router-link to="/" class="nav-logo">
          <span>Mi SitioWeb</span>
        </router-link>
        
        <button class="nav-toggle" @click="toggleMenu" aria-label="Toggle navigation">
          <i class="fas fa-bars"></i>
        </button>
        
        <ul class="nav-menu" :class="{ active: menuOpen }">
          <li class="nav-item">
            <router-link to="/" class="nav-link" @click="closeMenu">
              <i class="fas fa-home"></i>
              <span>Inicio</span>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link to="/harry" class="nav-link" @click="closeMenu">
              <i class="fas fa-hat-wizard"></i>
              <span>Harry Potter</span>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link to="/jugadores" class="nav-link" @click="closeMenu">
              <i class="fas fa-futbol"></i>
              <span>Jugadores</span>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link to="/perfil" class="nav-link" @click="closeMenu">
              <i class="fas fa-user"></i>
              <span>Mi Perfil</span>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link to="/usuarios" class="nav-link" @click="closeMenu">
              <i class="fas fa-database"></i>
              <span>Usuarios</span>
            </router-link>
          </li>
        </ul>
      </div>
    </nav>

    <!-- Contenido principal - aqui se cargan las vistas -->
    <main class="main-content">
      <router-view />
    </main>

    <!-- Footer -->
    <footer class="footer">
      <div class="footer-container"></div>
      <div class="footer-bottom">
        <p>&copy; 2026 Esteban Lebaza. Todos los derechos reservados.</p>
      </div>
    </footer>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const menuOpen = ref(false)

const toggleMenu = () => {
  menuOpen.value = !menuOpen.value
}

const closeMenu = () => {
  menuOpen.value = false
}
</script>

<style scoped>
#app {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.main-content {
  flex: 1;
}
</style>
