<template>
  <div class="card-container">
    <h1>{{ title }}</h1>
    <p>{{ subtitle }}</p>
    
    <!-- Filters (opcional) -->
    <div v-if="filters && filters.length > 0" class="filters">
      <button
        v-for="filter in filters"
        :key="filter.value"
        :class="{ active: activeFilter === filter.value }"
        @click="$emit('filter', filter.value)"
      >
        {{ filter.label }}
      </button>
    </div>

    <!-- Loading state -->
    <div v-if="loading" class="loading">
      <p>Cargando...</p>
    </div>

    <!-- Error state -->
    <div v-else-if="error" class="error">
      <p>{{ error }}</p>
    </div>

    <!-- Grid de cards -->
    <div v-else class="card-grid">
      <div
        v-for="item in items"
        :key="item.id"
        class="card"
        :class="{ vertical: vertical }"
        @click="$emit('select', item)"
      >
        <img :src="item.image" :alt="item.name">
        <div class="info">
          <h3>{{ item.name }}</h3>
          <p v-if="item.subtitle">{{ item.subtitle }}</p>
          <div v-if="item.details" class="details">
            <span v-for="(detail, index) in item.details" :key="index">
              <i v-if="detail.icon" :class="detail.icon"></i>
              {{ detail.text }}
            </span>
          </div>
        </div>
      </div>
    </div>

    <!-- Empty state -->
    <div v-if="!loading && !error && items.length === 0" class="loading">
      <p>No se encontraron resultados.</p>
    </div>
  </div>
</template>

<script setup>
defineProps({
  title: {
    type: String,
    required: true
  },
  subtitle: {
    type: String,
    default: ''
  },
  items: {
    type: Array,
    default: () => []
  },
  loading: {
    type: Boolean,
    default: false
  },
  error: {
    type: String,
    default: null
  },
  filters: {
    type: Array,
    default: () => []
  },
  activeFilter: {
    type: String,
    default: 'all'
  },
  vertical: {
    type: Boolean,
    default: false
  }
})

defineEmits(['select', 'filter'])
</script>
