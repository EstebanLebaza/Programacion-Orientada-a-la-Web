<template>
  <div class="detail-container">
    <button class="back-btn" @click="$emit('back')">
      <i class="fas fa-arrow-left"></i> Volver
    </button>
    
    <div class="detail-card">
      <img :src="item.image" :alt="item.name">
      <h3>{{ item.name }}</h3>
      <div class="info">
        <p v-for="(detail, index) in item.details" :key="index">
          <strong>{{ detail.label }}:</strong> {{ detail.value }}
        </p>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  item: {
    type: Object,
    required: true
  }
})

defineEmits(['back'])
</script>
