<template>
  <div class="home-container">
    <div class="hero">
      <h1>Bienvenido a Mi Portafolio</h1>
      <p>Explora las diferentes secciones de este sitio web creado con Vue.js</p>
    </div>
    
    <div class="home-grid">
      <router-link to="/harry" class="home-card">
        <div class="card-icon">
          <i class="fas fa-hat-wizard"></i>
        </div>
        <h3>Harry Potter</h3>
        <p>Explora los personajes de Hogwarts usando la API de Harry Potter</p>
      </router-link>
      
      <router-link to="/jugadores" class="home-card">
        <div class="card-icon">
          <i class="fas fa-futbol"></i>
        </div>
        <h3>Jugadores de Futbol</h3>
        <p>Conoce a los mejores jugadores de futbol del mundo</p>
      </router-link>
      
      <router-link to="/perfil" class="home-card">
        <div class="card-icon">
          <i class="fas fa-user"></i>
        </div>
        <h3>Mi Perfil</h3>
        <p>Conoce mas sobre mi experiencia y habilidades profesionales</p>
      </router-link>

      <router-link to="/usuarios" class="home-card">
        <div class="card-icon">
          <i class="fas fa-database"></i>
        </div>
        <h3>Usuarios (Backend)</h3>
        <p>CRUD de usuarios conectado al API REST con Express y PostgreSQL</p>
      </router-link>
    </div>
  </div>
</template>

<script setup>
</script>

<style scoped>
.home-container {
  padding: 1rem;
}

.hero {
  text-align: center;
  padding: 3rem 1rem;
  background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
  border-radius: var(--border-radius);
  color: white;
  margin-bottom: 2rem;
}

.hero h1 {
  font-size: 2.5rem;
  margin-bottom: 1rem;
}

.hero p {
  font-size: 1.1rem;
  opacity: 0.9;
}

.home-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 1.5rem;
}

.home-card {
  background: var(--white);
  border-radius: var(--border-radius);
  padding: 2rem;
  text-align: center;
  box-shadow: var(--shadow);
  transition: var(--transition);
  text-decoration: none;
  color: inherit;
}

.home-card:hover {
  transform: translateY(-5px);
  box-shadow: var(--shadow-hover);
}

.card-icon {
  width: 80px;
  height: 80px;
  margin: 0 auto 1rem;
  background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.card-icon i {
  font-size: 2rem;
  color: white;
}

.home-card h3 {
  font-size: 1.25rem;
  margin-bottom: 0.5rem;
  color: var(--dark-color);
}

.home-card p {
  color: var(--gray-color);
  font-size: 0.95rem;
}

@media (max-width: 768px) {
  .hero h1 {
    font-size: 1.75rem;
  }
  
  .hero p {
    font-size: 1rem;
  }
}
</style>
