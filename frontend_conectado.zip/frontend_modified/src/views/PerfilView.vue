<template>
  <div class="perfil-container">
    <!-- Loading -->
    <div v-if="loading" class="loading">
      <p>Cargando perfil...</p>
    </div>
    
    <!-- Error -->
    <div v-else-if="error" class="error">
      <p>{{ error }}</p>
    </div>
    
    <!-- Perfil Content -->
    <template v-else-if="perfil">
      <!-- Header -->
      <div class="perfil-header">
        <img :src="perfil.informacionPersonal.foto" :alt="perfil.informacionPersonal.nombre">
        <div class="header-info">
          <h1>{{ perfil.informacionPersonal.nombre }}</h1>
          <h2>{{ perfil.informacionPersonal.profesion }}</h2>
          <div class="contact-info">
            <span><i class="fas fa-envelope"></i> {{ perfil.informacionPersonal.correo }}</span>
            <span><i class="fas fa-phone"></i> {{ perfil.informacionPersonal.telefono }}</span>
            <span><i class="fas fa-map-marker-alt"></i> {{ perfil.informacionPersonal.ubicacion }}</span>
            <span><i class="fas fa-birthday-cake"></i> {{ perfil.informacionPersonal.fechaNacimiento }}</span>
          </div>
        </div>
      </div>

      <!-- Resumen -->
      <div class="perfil-summary">
        <h2><i class="fas fa-user"></i> Resumen Profesional</h2>
        <p>{{ perfil.resumen }}</p>
      </div>

      <!-- Grid de tarjetas -->
      <div class="perfil-grid">
        <!-- Educacion -->
        <div class="perfil-card">
          <h3><i class="fas fa-graduation-cap"></i> Educacion</h3>
          <div v-for="(edu, index) in perfil.educacion" :key="index" class="education-item">
            <h4>{{ edu.titulo }}</h4>
            <p>{{ edu.institucion }}</p>
            <span class="year">{{ edu.anoInicio }} - {{ edu.anoFin }}</span>
            <p style="font-size:0.85rem;margin-top:0.25rem;">{{ edu.descripcion }}</p>
          </div>
        </div>

        <!-- Experiencia -->
        <div class="perfil-card">
          <h3><i class="fas fa-briefcase"></i> Experiencia Laboral</h3>
          <div v-for="(exp, index) in perfil.experienciaLaboral" :key="index" class="experience-item">
            <h4>{{ exp.cargo }}</h4>
            <p>{{ exp.empresa }}</p>
            <span class="year">{{ exp.anoInicio }} - {{ exp.anoFin }}</span>
            <p style="font-size:0.85rem;margin-top:0.25rem;">{{ exp.descripcion }}</p>
          </div>
        </div>

        <!-- Habilidades -->
        <div class="perfil-card">
          <h3><i class="fas fa-tools"></i> Habilidades</h3>
          <div v-for="(skill, index) in perfil.habilidades" :key="index" class="skills-category">
            <h4>{{ skill.categoria }}</h4>
            <div class="skills-tags">
              <span v-for="(tech, techIndex) in skill.tecnologias" :key="techIndex" class="skill-tag">
                {{ tech }}
              </span>
            </div>
          </div>
        </div>

        <!-- Proyectos -->
        <div class="perfil-card">
          <h3><i class="fas fa-project-diagram"></i> Proyectos</h3>
          <div v-for="(proj, index) in perfil.proyectos" :key="index" class="project-item">
            <h4>{{ proj.nombre }}</h4>
            <div class="tech-stack">
              <span v-for="(tech, techIndex) in proj.tecnologias" :key="techIndex">{{ tech }}</span>
            </div>
            <p>{{ proj.descripcion }}</p>
          </div>
        </div>

        <!-- Idiomas -->
        <div class="perfil-card">
          <h3><i class="fas fa-language"></i> Idiomas</h3>
          <div v-for="(lang, index) in perfil.idiomas" :key="index" class="language-item">
            <span class="lang-name">{{ lang.idioma }}</span>
            <span class="lang-level">{{ lang.nivel }}</span>
          </div>
        </div>

        <!-- Intereses -->
        <div class="perfil-card">
          <h3><i class="fas fa-heart"></i> Intereses</h3>
          <div class="interests-list">
            <span v-for="(interes, index) in perfil.intereses" :key="index" class="interest-tag">
              {{ interes }}
            </span>
          </div>
        </div>
      </div>

      <!-- Meta -->
      <div class="perfil-grid">
        <div class="perfil-card meta-card">
          <h3><i class="fas fa-bullseye"></i> Mi Meta</h3>
          <p>{{ perfil.metas }}</p>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const perfil = ref(null)
const loading = ref(true)
const error = ref(null)

const loadPerfil = async () => {
  loading.value = true
  error.value = null
  
  try {
    const response = await axios.get('/data/perfil.json')
    perfil.value = response.data
  } catch (err) {
    console.error('Error cargando perfil:', err)
    error.value = 'Error al cargar el perfil. Intenta de nuevo mas tarde.'
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  loadPerfil()
})
</script>
