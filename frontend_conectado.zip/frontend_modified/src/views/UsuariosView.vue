<template>
  <div class="usuarios-container">
    <h1><i class="fas fa-users"></i> Usuarios</h1>
    <p class="subtitle">Datos obtenidos desde el backend (Express + PostgreSQL)</p>

    <!-- Formulario para crear usuario -->
    <div class="form-card">
      <h3>{{ editingId ? 'Editar Usuario' : 'Nuevo Usuario' }}</h3>
      <div class="form-row">
        <input v-model="form.name" placeholder="Nombre" />
        <input v-model="form.email" placeholder="Email" type="email" />
        <input
          v-if="!editingId"
          v-model="form.password"
          placeholder="Contraseña"
          type="password"
        />
        <button @click="submitForm" :disabled="submitting">
          {{ editingId ? 'Actualizar' : 'Crear' }}
        </button>
        <button v-if="editingId" @click="cancelEdit" class="btn-cancel">
          Cancelar
        </button>
      </div>
      <p v-if="formError" class="form-error">{{ formError }}</p>
    </div>

    <!-- Estado de carga / error -->
    <div v-if="loading" class="loading"><p>Cargando usuarios...</p></div>
    <div v-else-if="error" class="error"><p>{{ error }}</p></div>

    <!-- Tabla de usuarios -->
    <div v-else class="table-wrapper">
      <p v-if="users.length === 0" class="empty">No hay usuarios registrados aún.</p>
      <table v-else>
        <thead>
          <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Creado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="user in users" :key="user.id">
            <td>{{ user.id }}</td>
            <td>{{ user.name }}</td>
            <td>{{ user.email }}</td>
            <td>{{ formatDate(user.created_at) }}</td>
            <td class="actions">
              <button @click="startEdit(user)" class="btn-edit">
                <i class="fas fa-edit"></i>
              </button>
              <button @click="deleteUser(user.id)" class="btn-delete">
                <i class="fas fa-trash"></i>
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { userService } from '../services/api.js'

const users = ref([])
const loading = ref(true)
const error = ref(null)
const submitting = ref(false)
const formError = ref(null)
const editingId = ref(null)

const form = ref({ name: '', email: '', password: '' })

const loadUsers = async () => {
  loading.value = true
  error.value = null
  try {
    const res = await userService.getAll()
    users.value = res.data.data
  } catch (err) {
    error.value = 'No se pudo conectar con el backend. ¿Está corriendo en localhost:3000?'
  } finally {
    loading.value = false
  }
}

const submitForm = async () => {
  formError.value = null
  if (!form.value.name || !form.value.email) {
    formError.value = 'Nombre y email son obligatorios.'
    return
  }
  submitting.value = true
  try {
    if (editingId.value) {
      await userService.update(editingId.value, { name: form.value.name, email: form.value.email })
    } else {
      if (!form.value.password) { formError.value = 'La contraseña es obligatoria.'; return }
      await userService.create(form.value)
    }
    form.value = { name: '', email: '', password: '' }
    editingId.value = null
    await loadUsers()
  } catch (err) {
    formError.value = err.response?.data?.message || 'Error al guardar el usuario.'
  } finally {
    submitting.value = false
  }
}

const startEdit = (user) => {
  editingId.value = user.id
  form.value = { name: user.name, email: user.email, password: '' }
}

const cancelEdit = () => {
  editingId.value = null
  form.value = { name: '', email: '', password: '' }
  formError.value = null
}

const deleteUser = async (id) => {
  if (!confirm('¿Eliminar este usuario?')) return
  try {
    await userService.remove(id)
    await loadUsers()
  } catch (err) {
    alert('Error al eliminar el usuario.')
  }
}

const formatDate = (dateStr) => {
  if (!dateStr) return '-'
  return new Date(dateStr).toLocaleDateString('es-CO')
}

onMounted(loadUsers)
</script>

<style scoped>
.usuarios-container {
  padding: 1.5rem;
}

h1 {
  font-size: 1.8rem;
  margin-bottom: 0.25rem;
  color: var(--dark-color);
}

.subtitle {
  color: var(--gray-color);
  margin-bottom: 1.5rem;
}

/* Formulario */
.form-card {
  background: var(--white);
  border-radius: var(--border-radius);
  box-shadow: var(--shadow);
  padding: 1.25rem 1.5rem;
  margin-bottom: 1.5rem;
}

.form-card h3 {
  margin-bottom: 0.75rem;
  font-size: 1rem;
  color: var(--dark-color);
}

.form-row {
  display: flex;
  flex-wrap: wrap;
  gap: 0.6rem;
  align-items: center;
}

.form-row input {
  flex: 1 1 160px;
  padding: 0.5rem 0.75rem;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 0.9rem;
}

.form-row button {
  padding: 0.5rem 1.1rem;
  background: var(--primary-color);
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.9rem;
  transition: var(--transition);
}

.form-row button:hover { opacity: 0.85; }
.form-row button:disabled { opacity: 0.5; cursor: not-allowed; }

.btn-cancel {
  background: var(--gray-color) !important;
}

.form-error {
  color: #e74c3c;
  font-size: 0.85rem;
  margin-top: 0.5rem;
}

/* Tabla */
.table-wrapper {
  background: var(--white);
  border-radius: var(--border-radius);
  box-shadow: var(--shadow);
  overflow: hidden;
}

table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.92rem;
}

thead {
  background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
  color: white;
}

th, td {
  padding: 0.75rem 1rem;
  text-align: left;
}

tbody tr:nth-child(even) { background: #f9f9f9; }
tbody tr:hover { background: #f0f4ff; }

.actions { display: flex; gap: 0.4rem; }

.btn-edit, .btn-delete {
  border: none;
  border-radius: 5px;
  padding: 0.35rem 0.6rem;
  cursor: pointer;
  font-size: 0.85rem;
  color: white;
}

.btn-edit { background: #3498db; }
.btn-delete { background: #e74c3c; }

.empty {
  text-align: center;
  padding: 2rem;
  color: var(--gray-color);
}

.loading, .error {
  text-align: center;
  padding: 2rem;
}

.error p { color: #e74c3c; }

@media (max-width: 600px) {
  .form-row input { flex: 1 1 100%; }
}
</style>
