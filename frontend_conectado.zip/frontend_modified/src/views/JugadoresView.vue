<template>
  <div>
    <!-- Vista de detalle -->
    <CardDetail
      v-if="selectedJugador"
      :item="selectedJugadorDetail"
      @back="selectedJugador = null"
    />
    
    <!-- Vista de lista -->
    <CardGrid
      v-else
      title="Jugadores de Futbol"
      subtitle="Haz clic en un jugador para ver mas informacion"
      :items="transformedJugadores"
      :loading="loading"
      :error="error"
      :vertical="true"
      @select="selectJugador"
    />
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import axios from 'axios'
import CardGrid from '../components/CardGrid.vue'
import CardDetail from '../components/CardDetail.vue'

const jugadores = ref([])
const loading = ref(true)
const error = ref(null)
const selectedJugador = ref(null)

// Transformar datos para el componente CardGrid
const transformedJugadores = computed(() => {
  return jugadores.value.map(jugador => ({
    id: jugador.id,
    name: jugador.nombre,
    image: jugador.foto,
    details: [
      { icon: 'fas fa-birthday-cake', text: jugador.fechaNacimiento },
      { icon: 'fas fa-ruler-vertical', text: jugador.estatura },
      { icon: 'fas fa-user', text: `${jugador.edad} años` }
    ],
    // Datos originales para el detalle
    original: jugador
  }))
})

const selectedJugadorDetail = computed(() => {
  if (!selectedJugador.value) return null
  
  const jugador = selectedJugador.value.original
  
  return {
    name: jugador.nombre,
    image: jugador.foto,
    details: [
      { label: 'Fecha de nacimiento', value: jugador.fechaNacimiento },
      { label: 'Edad', value: `${jugador.edad} años` },
      { label: 'Estatura', value: jugador.estatura },
      { label: 'Posicion', value: jugador.posicion }
    ]
  }
})

const loadJugadores = async () => {
  loading.value = true
  error.value = null
  
  try {
    const response = await axios.get('/data/jugadores.json')
    jugadores.value = response.data
  } catch (err) {
    console.error('Error cargando jugadores:', err)
    error.value = 'Error al cargar los jugadores. Intenta de nuevo mas tarde.'
  } finally {
    loading.value = false
  }
}

const selectJugador = (jugador) => {
  selectedJugador.value = jugador
}

onMounted(() => {
  loadJugadores()
})
</script>
