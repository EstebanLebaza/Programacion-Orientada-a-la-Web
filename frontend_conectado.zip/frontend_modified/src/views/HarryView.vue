<template>
  <div>
    <!-- Vista de detalle -->
    <CardDetail
      v-if="selectedCharacter"
      :item="selectedCharacterDetail"
      @back="selectedCharacter = null"
    />
    
    <!-- Vista de lista -->
    <CardGrid
      v-else
      title="Lista de Personajes - Hogwarts"
      subtitle="Selecciona un personaje para ver mas informacion"
      :items="filteredCharacters"
      :loading="loading"
      :error="error"
      :filters="houseFilters"
      :active-filter="activeFilter"
      @filter="filterByHouse"
      @select="selectCharacter"
    />
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import axios from 'axios'
import CardGrid from '../components/CardGrid.vue'
import CardDetail from '../components/CardDetail.vue'

const characters = ref([])
const loading = ref(true)
const error = ref(null)
const activeFilter = ref('all')
const selectedCharacter = ref(null)

const houseFilters = [
  { value: 'all', label: 'Todos' },
  { value: 'Gryffindor', label: 'Gryffindor' },
  { value: 'Slytherin', label: 'Slytherin' },
  { value: 'Ravenclaw', label: 'Ravenclaw' },
  { value: 'Hufflepuff', label: 'Hufflepuff' }
]

// Transformar datos para el componente CardGrid
const transformedCharacters = computed(() => {
  return characters.value.map(char => ({
    id: char.id,
    name: char.name,
    image: char.image,
    subtitle: char.house || 'Sin casa',
    house: char.house,
    // Datos originales para el detalle
    original: char
  }))
})

const filteredCharacters = computed(() => {
  if (activeFilter.value === 'all') {
    return transformedCharacters.value
  }
  return transformedCharacters.value.filter(char => char.house === activeFilter.value)
})

const selectedCharacterDetail = computed(() => {
  if (!selectedCharacter.value) return null
  
  const char = selectedCharacter.value.original
  const age = char.yearOfBirth ? new Date().getFullYear() - char.yearOfBirth : 'Desconocida'
  const alternateNames = char.alternate_names?.length > 0 ? char.alternate_names.join(', ') : 'Ninguno'
  
  return {
    name: char.name,
    image: char.image,
    details: [
      { label: 'Casa', value: char.house || 'Sin casa' },
      { label: 'Especie', value: char.species || 'Desconocida' },
      { label: 'Fecha de nacimiento', value: char.dateOfBirth || 'Desconocida' },
      { label: 'Genero', value: char.gender || 'Desconocido' },
      { label: 'Edad', value: age },
      { label: 'Nombres alternativos', value: alternateNames }
    ]
  }
})

const loadCharacters = async () => {
  loading.value = true
  error.value = null
  
  try {
    const response = await axios.get('https://hp-api.onrender.com/api/characters')
    // Filtrar solo personajes con imagen y limitar a 20
    characters.value = response.data.filter(c => c.image !== '').slice(0, 20)
  } catch (err) {
    console.error('Error cargando personajes:', err)
    error.value = 'Error al cargar los personajes. Intenta de nuevo mas tarde.'
  } finally {
    loading.value = false
  }
}

const filterByHouse = (house) => {
  activeFilter.value = house
}

const selectCharacter = (character) => {
  selectedCharacter.value = character
}

onMounted(() => {
  loadCharacters()
})
</script>
